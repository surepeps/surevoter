for(let u = 2; u = 5;){
    console.log(u)
    u = u + 1;
}